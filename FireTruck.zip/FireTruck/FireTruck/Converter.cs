﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace FireTruck
{
    public class MessageConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            MessageCodes msgCode = (MessageCodes)value;
            string message = "";
            if (msgCode != MessageCodes.NO_ERROR)
            {
                switch (msgCode)
                {
                    case MessageCodes.ERROR_PROCESS:
                        message = "Error is processing Data";
                        break;
                    case MessageCodes.INVALID_FILE:
                        message = "Invalid file. Please try again.";
                        break;
                    case MessageCodes.NO_DATA:
                        message = "No data available.";
                        break;
                }
            }
            return message;
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
    public class PriorityBackgroundConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            Priority priority = (Priority)value;
            string color = "";
            switch ((Priority)value)
            {
                case Priority.LOW:
                    color = "IndianRed";
                    break;
                case Priority.MEDIUM:
                    color = "Gold";
                    break;
                case Priority.HIGH:
                    color = "SeaGreen";
                    break;
            }
            return color;
        }
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
