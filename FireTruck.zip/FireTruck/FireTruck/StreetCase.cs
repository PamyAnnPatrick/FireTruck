﻿using System.Collections.Generic;
using System.ComponentModel;
namespace FireTruck
{
    public class StreetCase
    {
        public Dictionary<int, List<int>> Map = new Dictionary<int, List<int>>();
        public BindingList<Solution> Solutions { get; set; } = new BindingList<Solution>();
        public int FireStreet { get; set; }
        public int CaseNumber { get; set; }
        public int SolutionCount { get; set; }
        public bool ShowSolution { get; set; } = true;
        public MessageCodes MsgCode { get; set; } = MessageCodes.NO_ERROR;
        public bool IsDeadLock { get; set; } = true;
    }
    public class Solution
    {
        public List<int> Paths { get; set; } = new List<int>();
        public Priority Priority { get; set; }
        public int StreetCount { get; set; }
    }
}
