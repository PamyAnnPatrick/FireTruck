﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;

namespace FireTruck
{
    public enum MessageCodes
    {
        ERROR_PROCESS,
        INVALID_FILE,
        NO_DATA,
        NO_ERROR
    }
    public enum Priority
    {
        LOW,
        MEDIUM,
        HIGH
    }
    class VM : INotifyPropertyChanged
    {
        public const int MAX_STREET = 21;
        public const int FIRE_STATION = 1;
        public static readonly char[] DELIMITER = new char[] { ' ' };
        private BindingList<StreetCase> streetCases = new BindingList<StreetCase>();
        public BindingList<StreetCase> StreetCases { get => streetCases; set { streetCases = value; onChange(); } }
        public void Submit()
        {
            Browse();
            Calculate();
        }
        public void Browse()
        {
            try
            {
                OpenFileDialog fileDialog = new OpenFileDialog();
                fileDialog.DefaultExt = ".txt";
                fileDialog.Filter = "Text documents (.txt)|*.txt";
                if (fileDialog.ShowDialog() == true)
                {
                    ProcessFileData(fileDialog.FileName);
                }
            }
            catch (Exception)
            {
                showError(MessageCodes.INVALID_FILE);
            }
        }
        public void ProcessFileData(string filePath)
        {
            try
            {
                bool isNewCase = true;
                StreetCases.Clear();
                int caseNum = 1;
                StreetCase s = new StreetCase();
                string[] lines = File.ReadAllLines(filePath);
                if (lines.Count() == 0)
                    showError(MessageCodes.NO_DATA);
                foreach (string line in lines)
                {
                    string[] items = line.Split(DELIMITER, StringSplitOptions.RemoveEmptyEntries);
                    if (isNewCase)
                    {
                        if (items.Length > 1)
                        {
                            // if no fire street defined in new case
                            break;
                        }
                        s.FireStreet = Convert.ToInt32(items[0]);
                        isNewCase = false;
                    }
                    else if (items.Length == 2)
                    {
                        int street1 = Convert.ToInt32(items[0]);
                        int street2 = Convert.ToInt32(items[1]);
                        if ((street1 > MAX_STREET) || (street2 > MAX_STREET))
                        {
                            // exceeeds the limit of street
                            break;
                        }
                        else if ((street1 > 0) && (street2 > 0))
                        {
                            addStreet(s, street1, street2);
                        }
                        else if ((street1 == 0) && (street2 == 0))
                        {
                            isNewCase = true;
                            s.CaseNumber = caseNum++;
                            StreetCases.Add(s);
                            s = new StreetCase();
                        }
                    }
                    else
                    {
                        //incorrect path
                        break;
                    }
                }
            }
            catch (Exception)
            {
                showError(MessageCodes.INVALID_FILE);
            }
        }
        public void Calculate()
        {
            foreach (StreetCase s in StreetCases)
            {
                try
                {
                    if (!s.IsDeadLock)
                    {
                        List<int> path = new List<int>();
                        s.Solutions.Clear();
                        List<int> sol = getNext(s, path, FIRE_STATION);
                        s.SolutionCount = s.Solutions.Count;
                        // setting priority for color 
                        s.Solutions.Where(c => c.StreetCount == (from x in s.Solutions select x.StreetCount).Min()).ToList().ForEach(cc => cc.Priority = Priority.HIGH);
                        s.Solutions.Where(c => c.StreetCount == (from x in s.Solutions select x.StreetCount).Max()).ToList().ForEach(cc => cc.Priority = Priority.LOW);
                    }
                }
                catch (Exception)
                {
                    s.MsgCode = MessageCodes.ERROR_PROCESS;
                    s.Solutions.Clear();
                }
            }
        }
        private List<int> getNext(StreetCase s, List<int> path, int currentStreet)
        {
            if (path.Contains(currentStreet))
            {
                //no solution for the path
            }
            else if (currentStreet != s.FireStreet)
            {
                path.Add(currentStreet);
                int n = s.Map[currentStreet].Count;
                for (int i = 0; i < n; i++)
                    getNext(s,new List<int>(path), s.Map[currentStreet].ElementAt(i));
            }
            else if (currentStreet == s.FireStreet)
            {
                path.Add(currentStreet);
                s.Solutions.Add(new Solution() { Paths = path, StreetCount = path.Count, Priority = Priority.MEDIUM });
            }
            return path;
        }
        private void addValue(StreetCase s, int key, int value)
        {
            if (!s.Map.ContainsKey(key))
                s.Map.Add(key, new List<int>());
            if (!s.Map[key].Contains(value))
                s.Map[key].Add(value);
        }
        private void addStreet(StreetCase s, int street1, int street2)
        {
            if (s.FireStreet == street2)
                s.IsDeadLock = false;
            addValue(s, street1, street2);
            addValue(s, street2, street1);
        }
        private void showError(MessageCodes msg)
        {
            StreetCases = new BindingList<StreetCase> { new StreetCase { MsgCode = msg, ShowSolution = false } };
        }
        #region PropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        private void onChange([CallerMemberName] String propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
